﻿namespace Edt.Prcatice.Mobile;

public partial class MainPage : ContentPage
{
    public MainPage()
    {
        InitializeComponent();
    }

    private async void Button_OnClicked(object? sender, EventArgs e)
    {
        await DisplayAlertAsync("Информация", "Приложение готово к работе!", "OK");
    }
}