﻿using Microsoft.Extensions.DependencyInjection;

namespace Edt.Prcatice.Mobile;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        return new Window(new AppShell());
    }
}